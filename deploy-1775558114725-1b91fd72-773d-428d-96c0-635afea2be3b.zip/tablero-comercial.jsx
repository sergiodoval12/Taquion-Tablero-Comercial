import { useState, useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid, Legend, RadialBarChart, RadialBar } from "recharts";

// ═══════════════════════════════════════════════════════════════
// TABLERO DEL DIRECTOR COMERCIAL — GRUPO TAQUION 2026
// Target anual: $4,200M ARS
// Datos: Notion CRM (Forecast + Funnel + Cuentas Activas)
// Actualizado: Abril 2026
// ═══════════════════════════════════════════════════════════════

const COLORS = {
  dark: "#1A1A2E",
  accent: "#E94560",
  accentLight: "#FF6B81",
  blue: "#4361EE",
  blueLight: "#5C7CFA",
  green: "#2ECC71",
  greenDark: "#27AE60",
  yellow: "#F39C12",
  orange: "#E67E22",
  red: "#E74C3C",
  purple: "#9B59B6",
  teal: "#1ABC9C",
  gray: "#95A5A6",
  grayLight: "#BDC3C7",
  bg: "#0F0F1A",
  card: "#16213E",
  cardHover: "#1A2744",
  text: "#ECF0F1",
  textMuted: "#95A5A6",
  border: "#2C3E6D",
};

// ══════ DATA ══════
const TARGET_ANUAL = 4200;
const quarterTargets = { Q1: 650, Q2: 850, Q3: 1200, Q4: 1500 };

const revenueData = [
  { mes: "Ene", real2026: 180, target2026: 183, real2025: 120 },
  { mes: "Feb", real2026: 195, target2026: 200, real2025: 135 },
  { mes: "Mar", real2026: 224.6, target2026: 267, real2025: 155 },
  { mes: "Abr", real2026: 210, target2026: 250, real2025: 160 },
  { mes: "May", real2026: 245, target2026: 280, real2025: 175 },
  { mes: "Jun", real2026: 268.1, target2026: 320, real2025: 190 },
  { mes: "Jul", real2026: null, target2026: 350, real2025: 200 },
  { mes: "Ago", real2026: null, target2026: 380, real2025: 210 },
  { mes: "Sep", real2026: null, target2026: 400, real2025: 220 },
  { mes: "Oct", real2026: null, target2026: 420, real2025: 240 },
  { mes: "Nov", real2026: null, target2026: 450, real2025: 260 },
  { mes: "Dic", real2026: null, target2026: 500, real2025: 280 },
];

const quarterData = [
  { q: "Q1", real: 599.6, target: 650, prev: 410, pct: 92, status: "warning" },
  { q: "Q2", real: 723.1, target: 850, prev: 525, pct: 85, status: "warning", projected: true },
  { q: "Q3", real: 615.4, target: 1200, prev: 630, pct: 51, status: "danger", projected: true },
  { q: "Q4", real: 591.1, target: 1500, prev: 780, pct: 39, status: "danger", projected: true },
];

const cuentasActivas = [
  { nombre: "La Pampa", tipo: "Recurrente", industria: "Public Affairs", servicio: "Social Listening", am: "Sol/Servicio", comercial: "Sergio", ticketMes: 18 },
  { nombre: "Suther", tipo: "Recurrente", industria: "Public Affairs", servicio: "Comunicación estratégica", am: "Sol", comercial: "Sergio", ticketMes: 15 },
  { nombre: "UATRE", tipo: "Recurrente", industria: "Public Affairs", servicio: "Alertas + Comunidades", am: "Angie", comercial: "Sol", ticketMes: 12 },
  { nombre: "ALEA", tipo: "Recurrente", industria: "Public Affairs", servicio: "Posicionamiento institucional", am: "Lau/Sol", comercial: "Sergio", ticketMes: 10 },
  { nombre: "Boca", tipo: "Recurrente", industria: "Entretenimiento / Deportes", servicio: "Campaña", am: "Martín/Nico", comercial: "Sergio", ticketMes: 25 },
  { nombre: "Enfoque Federal", tipo: "Recurrente", industria: "Public Affairs", servicio: "Talk About / Comunidades", am: "Julián/Sol", comercial: "Sergio", ticketMes: 8 },
  { nombre: "CAEM", tipo: "Recurrente", industria: "Energía / Minería", servicio: "Social Listening", am: "Servicio/Martín", comercial: "Diego", ticketMes: 7 },
  { nombre: "Naranja X", tipo: "Recurrente", industria: "Banca & Fintech", servicio: "Banca & Fintech", am: "Martín", comercial: "Diego", ticketMes: 20 },
  { nombre: "Finadina", tipo: "Recurrente", industria: "Banca & Fintech", servicio: "Investigación + Social Listening", am: "Julián", comercial: "Sergio", ticketMes: 14 },
  { nombre: "Froneri", tipo: "Recurrente", industria: "Consumo Masivo", servicio: "UGC y pauta", am: "Sol", comercial: "Diego", ticketMes: 12 },
  { nombre: "San Luis", tipo: "Recurrente", industria: "Public Affairs", servicio: "Comunidades + Rebranding", am: "Julián", comercial: "Sergio", ticketMes: 9 },
  { nombre: "Rosbaco", tipo: "Recurrente", industria: "Otro", servicio: "Estrategia comercial", am: "Sol/Martín", comercial: "Sergio", ticketMes: 6 },
  { nombre: "Banco Ciudad", tipo: "Recurrente", industria: "Banca & Fintech", servicio: "Comunidades", am: "Sol", comercial: "Sergio", ticketMes: 11 },
  { nombre: "Potrero Encanta", tipo: "Recurrente", industria: "Turismo", servicio: "Comunicación creativa", am: "Sol/Martín", comercial: "Sergio", ticketMes: 5 },
  { nombre: "Aerolíneas", tipo: "One Shot", industria: "Public Affairs", servicio: "Social Listening", am: "Sol/Joaco", comercial: "Sol", ticketMes: 15 },
  { nombre: "Farmapay", tipo: "One Shot", industria: "Banca & Fintech", servicio: "Investigación + Posicionamiento", am: "Sol", comercial: "Diego", ticketMes: 10 },
  { nombre: "Banco Galicia/NAVE", tipo: "One Shot", industria: "Banca & Fintech", servicio: "Investigación Cuanti", am: "Julián", comercial: "Diego", ticketMes: 18 },
  { nombre: "Credicuotas", tipo: "One Shot", industria: "Banca & Fintech", servicio: "Comunidades", am: "Julián", comercial: "Diego", ticketMes: 8 },
  { nombre: "GET NET", tipo: "One Shot", industria: "Banca & Fintech", servicio: "Investigación Cuanti", am: "Juli/Martín", comercial: "Diego", ticketMes: 7 },
  { nombre: "Coca Cola", tipo: "One Shot", industria: "Consumo Masivo", servicio: "Comunicación creativa", am: "Sol/Martín", comercial: "Sergio", ticketMes: 22 },
  { nombre: "Moiguer", tipo: "One Shot", industria: "Otro", servicio: "Social Listening", am: "Servicio", comercial: "Diego", ticketMes: 5 },
  { nombre: "NASA", tipo: "One Shot", industria: "Energía / Minería", servicio: "Investigación Cuanti", am: "Martín", comercial: "Diego", ticketMes: 12 },
  { nombre: "YDI", tipo: "One Shot", industria: "Banca & Fintech", servicio: "Banca & Fintech", am: "Sol", comercial: "Diego", ticketMes: 8 },
  { nombre: "CEC", tipo: "One Shot", industria: "Entretenimiento / Deportes", servicio: "Comunidades", am: "Juli/Martín", comercial: "Sergio", ticketMes: 6 },
  { nombre: "Todo un País", tipo: "One Shot", industria: "Public Affairs", servicio: "Comunidades", am: "Sol", comercial: "Sergio", ticketMes: 7 },
  { nombre: "BEM", tipo: "One Shot", industria: "Energía / Minería", servicio: "Estrategia de contenidos", am: "Santi Pegito", comercial: "Sergio", ticketMes: 9 },
  { nombre: "MercadoPago Jubi", tipo: "One Shot", industria: "Banca & Fintech", servicio: "Investigación + Prensa", am: "Sol", comercial: "Sergio", ticketMes: 16 },
];

const pipelineQ2 = [
  { nombre: "GCBA – Angelici", ticketMes: 30, inicio: "Abr/May", industria: "Public Affairs", probabilidad: 70 },
  { nombre: "Comunidad AI GCBA", ticketMes: 15, inicio: "Abr/May", industria: "Tecnología / IA", probabilidad: 60 },
  { nombre: "Agencia Restart", ticketMes: 15, inicio: "Abr/May", industria: "Otro", probabilidad: 55 },
  { nombre: "Comunidad Banca & Fintech", ticketMes: 15, inicio: "Abr", industria: "Banca & Fintech", probabilidad: 75 },
  { nombre: "Pet Food Saladillo", ticketMes: 10, inicio: "Abr/May", industria: "Consumo Masivo", probabilidad: 50 },
  { nombre: "Lotba", ticketMes: 10, inicio: "Abr", industria: "Entretenimiento / Deportes", probabilidad: 65 },
  { nombre: "Ola Palermo", ticketMes: 6, inicio: "Abr", industria: "Otro", probabilidad: 60 },
];

const funnelStages = [
  { stage: "Lead", count: 18, value: 280 },
  { stage: "Pipeline", count: 12, value: 195 },
  { stage: "Upside", count: 8, value: 140 },
  { stage: "Forecast", count: 5, value: 95 },
  { stage: "Commit", count: 3, value: 72 },
  { stage: "Won (Q1)", count: 14, value: 599.6 },
];

const industryColors = {
  "Public Affairs": COLORS.blue,
  "Banca & Fintech": COLORS.green,
  "Consumo Masivo": COLORS.orange,
  "Entretenimiento / Deportes": COLORS.purple,
  "Energía / Minería": COLORS.teal,
  "Turismo": COLORS.yellow,
  "Tecnología / IA": COLORS.accentLight,
  "Otro": COLORS.gray,
};

// ══════ COMPONENTS ══════

const KPICard = ({ title, value, subtitle, trend, trendDirection, color = COLORS.accent, icon }) => (
  <div style={{ background: COLORS.card, borderRadius: 12, padding: "20px 24px", border: `1px solid ${COLORS.border}`, position: "relative", overflow: "hidden" }}>
    <div style={{ position: "absolute", top: 0, left: 0, width: 4, height: "100%", background: color }} />
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
      <div>
        <div style={{ color: COLORS.textMuted, fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>{title}</div>
        <div style={{ color: COLORS.text, fontSize: 28, fontWeight: 700, lineHeight: 1.1 }}>{value}</div>
        {subtitle && <div style={{ color: COLORS.textMuted, fontSize: 12, marginTop: 6 }}>{subtitle}</div>}
      </div>
      {trend && (
        <div style={{ background: trendDirection === "up" ? "rgba(46,204,113,0.15)" : trendDirection === "down" ? "rgba(231,76,60,0.15)" : "rgba(243,156,18,0.15)", color: trendDirection === "up" ? COLORS.green : trendDirection === "down" ? COLORS.red : COLORS.yellow, padding: "4px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600 }}>
          {trendDirection === "up" ? "▲" : trendDirection === "down" ? "▼" : "●"} {trend}
        </div>
      )}
    </div>
  </div>
);

const SectionTitle = ({ children, accent = COLORS.accent }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, marginTop: 32 }}>
    <div style={{ width: 4, height: 24, background: accent, borderRadius: 2 }} />
    <h2 style={{ color: COLORS.text, fontSize: 18, fontWeight: 700, margin: 0 }}>{children}</h2>
  </div>
);

const ProgressBar = ({ value, max, color = COLORS.accent, height = 8, showLabel = true }) => {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <div style={{ width: "100%" }}>
      <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: height / 2, height, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: `linear-gradient(90deg, ${color}, ${color}99)`, borderRadius: height / 2, transition: "width 0.5s ease" }} />
      </div>
      {showLabel && <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
        <span style={{ color: COLORS.textMuted, fontSize: 11 }}>${value.toFixed(0)}M</span>
        <span style={{ color: COLORS.textMuted, fontSize: 11 }}>{pct.toFixed(0)}%</span>
      </div>}
    </div>
  );
};

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 8, padding: "10px 14px", boxShadow: "0 8px 24px rgba(0,0,0,0.4)" }}>
      <div style={{ color: COLORS.text, fontWeight: 600, marginBottom: 6, fontSize: 13 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color, fontSize: 12, marginBottom: 2 }}>
          {p.name}: <strong>${p.value?.toFixed(1)}M</strong>
        </div>
      ))}
    </div>
  );
};

// ══════ MAIN DASHBOARD ══════

export default function TableroComercial() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedIndustry, setSelectedIndustry] = useState("Todas");

  const totalReal = quarterData.reduce((s, q) => s + q.real, 0);
  const gapAnual = TARGET_ANUAL - totalReal;
  const pctAnual = ((totalReal / TARGET_ANUAL) * 100).toFixed(1);
  const recurrentes = cuentasActivas.filter(c => c.tipo === "Recurrente");
  const oneShots = cuentasActivas.filter(c => c.tipo === "One Shot");
  const ticketPromedio = (cuentasActivas.reduce((s, c) => s + c.ticketMes, 0) / cuentasActivas.length).toFixed(1);
  const totalPipeline = pipelineQ2.reduce((s, p) => s + p.ticketMes, 0);
  const pipelinePonderado = pipelineQ2.reduce((s, p) => s + (p.ticketMes * p.probabilidad / 100), 0);

  const industryBreakdown = useMemo(() => {
    const map = {};
    cuentasActivas.forEach(c => {
      if (!map[c.industria]) map[c.industria] = { name: c.industria, cuentas: 0, revenue: 0 };
      map[c.industria].cuentas++;
      map[c.industria].revenue += c.ticketMes;
    });
    return Object.values(map).sort((a, b) => b.revenue - a.revenue);
  }, []);

  const comercialBreakdown = useMemo(() => {
    const map = {};
    cuentasActivas.forEach(c => {
      const key = c.comercial;
      if (!map[key]) map[key] = { name: key, cuentas: 0, revenue: 0 };
      map[key].cuentas++;
      map[key].revenue += c.ticketMes;
    });
    return Object.values(map).sort((a, b) => b.revenue - a.revenue);
  }, []);

  const filteredCuentas = selectedIndustry === "Todas" ? cuentasActivas : cuentasActivas.filter(c => c.industria === selectedIndustry);
  const industries = ["Todas", ...new Set(cuentasActivas.map(c => c.industria))];

  const tabs = [
    { id: "overview", label: "Resumen Ejecutivo" },
    { id: "revenue", label: "Revenue & Quarters" },
    { id: "accounts", label: "Cuentas & Industrias" },
    { id: "pipeline", label: "Pipeline & Funnel" },
    { id: "team", label: "Equipo Comercial" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: COLORS.bg, color: COLORS.text, fontFamily: "'Inter', -apple-system, sans-serif" }}>
      {/* Header */}
      <div style={{ background: `linear-gradient(135deg, ${COLORS.dark} 0%, #16213E 100%)`, borderBottom: `2px solid ${COLORS.accent}`, padding: "24px 32px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 40, height: 40, background: COLORS.accent, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, fontWeight: 800 }}>T</div>
              <div>
                <h1 style={{ margin: 0, fontSize: 22, fontWeight: 800, letterSpacing: -0.5 }}>TABLERO DEL DIRECTOR COMERCIAL</h1>
                <div style={{ color: COLORS.textMuted, fontSize: 13 }}>Grupo Taquion — Año Fiscal 2026</div>
              </div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <div style={{ textAlign: "right" }}>
              <div style={{ color: COLORS.textMuted, fontSize: 11, textTransform: "uppercase" }}>Target Anual</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: COLORS.accent }}>$4,200M</div>
            </div>
            <div style={{ width: 1, height: 40, background: COLORS.border }} />
            <div style={{ textAlign: "right" }}>
              <div style={{ color: COLORS.textMuted, fontSize: 11, textTransform: "uppercase" }}>Actualizado</div>
              <div style={{ fontSize: 14, fontWeight: 600 }}>Abril 2026</div>
            </div>
          </div>
        </div>
        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, marginTop: 20, overflowX: "auto" }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)} style={{ padding: "8px 20px", borderRadius: "8px 8px 0 0", border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600, transition: "all 0.2s", background: activeTab === t.id ? COLORS.accent : "transparent", color: activeTab === t.id ? "#fff" : COLORS.textMuted }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: "24px 32px", maxWidth: 1400, margin: "0 auto" }}>

        {/* ══════ TAB: OVERVIEW ══════ */}
        {activeTab === "overview" && (
          <div>
            {/* KPIs Row */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
              <KPICard title="Facturación Proyectada" value={`$${totalReal.toFixed(0)}M`} subtitle={`de $${TARGET_ANUAL}M target (${pctAnual}%)`} trend={`Gap: $${gapAnual.toFixed(0)}M`} trendDirection="down" color={COLORS.red} />
              <KPICard title="Cuentas Activas" value={cuentasActivas.length} subtitle={`${recurrentes.length} recurrentes · ${oneShots.length} one-shots`} trend="78% recurrencia" trendDirection="up" color={COLORS.green} />
              <KPICard title="Pipeline Q2" value={`$${totalPipeline}M/mes`} subtitle={`Ponderado: $${pipelinePonderado.toFixed(0)}M/mes`} trend={`${pipelineQ2.length} oportunidades`} trendDirection="neutral" color={COLORS.blue} />
              <KPICard title="Ticket Promedio" value={`$${ticketPromedio}M`} subtitle="por cuenta activa/mes" trend="vs $9.2M en 2025" trendDirection="up" color={COLORS.purple} />
              <KPICard title="Runway" value="3 meses" subtitle="Objetivo: 9 meses" trend="Crítico" trendDirection="down" color={COLORS.red} />
              <KPICard title="Gap Mensual" value="+$30M/mes" subtitle="en nuevas cuentas para cerrar gap" trend="Prioridad #1" trendDirection="down" color={COLORS.orange} />
            </div>

            {/* Quarter Performance */}
            <SectionTitle>Performance por Quarter vs Target</SectionTitle>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
              {quarterData.map(q => (
                <div key={q.q} style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}` }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                    <span style={{ fontSize: 16, fontWeight: 700 }}>{q.q}</span>
                    <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 12, fontWeight: 600, background: q.status === "warning" ? "rgba(243,156,18,0.15)" : "rgba(231,76,60,0.15)", color: q.status === "warning" ? COLORS.yellow : COLORS.red }}>
                      {q.pct}% {q.projected ? "(proj)" : ""}
                    </span>
                  </div>
                  <div style={{ fontSize: 24, fontWeight: 800, color: q.pct >= 90 ? COLORS.green : q.pct >= 70 ? COLORS.yellow : COLORS.red }}>
                    ${q.real.toFixed(0)}M
                  </div>
                  <ProgressBar value={q.real} max={q.target} color={q.pct >= 90 ? COLORS.green : q.pct >= 70 ? COLORS.yellow : COLORS.red} />
                  <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, fontSize: 11, color: COLORS.textMuted }}>
                    <span>Target: ${q.target}M</span>
                    <span>2025: ${q.prev}M ({((q.real / q.prev - 1) * 100).toFixed(0)}% YoY)</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Revenue Chart + Industry Pie */}
            <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16, marginTop: 24 }}>
              <div style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}` }}>
                <div style={{ color: COLORS.textMuted, fontSize: 12, fontWeight: 600, textTransform: "uppercase", marginBottom: 16 }}>Revenue Mensual: Real 2026 vs Target vs 2025</div>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={revenueData} barGap={2}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} />
                    <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="real2026" name="Real 2026" fill={COLORS.accent} radius={[4, 4, 0, 0]} />
                    <Bar dataKey="target2026" name="Target 2026" fill={COLORS.blue} radius={[4, 4, 0, 0]} opacity={0.4} />
                    <Bar dataKey="real2025" name="Real 2025" fill={COLORS.gray} radius={[4, 4, 0, 0]} opacity={0.3} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}` }}>
                <div style={{ color: COLORS.textMuted, fontSize: 12, fontWeight: 600, textTransform: "uppercase", marginBottom: 8 }}>Revenue por Industria</div>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={industryBreakdown} cx="50%" cy="50%" innerRadius={45} outerRadius={80} paddingAngle={2} dataKey="revenue" nameKey="name">
                      {industryBreakdown.map((entry, i) => (
                        <Cell key={i} fill={industryColors[entry.name] || COLORS.gray} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v) => `$${v}M/mes`} contentStyle={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 4 }}>
                  {industryBreakdown.slice(0, 5).map((ind, i) => (
                    <span key={i} style={{ fontSize: 10, padding: "2px 8px", borderRadius: 10, background: `${industryColors[ind.name] || COLORS.gray}22`, color: industryColors[ind.name] || COLORS.gray }}>
                      {ind.name.split("/")[0].trim()} ({ind.cuentas})
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ══════ TAB: REVENUE ══════ */}
        {activeTab === "revenue" && (
          <div>
            <SectionTitle>Evolución de Revenue Mensual</SectionTitle>
            <div style={{ background: COLORS.card, borderRadius: 12, padding: 24, border: `1px solid ${COLORS.border}` }}>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 12 }} />
                  <YAxis tick={{ fill: COLORS.textMuted, fontSize: 12 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ fontSize: 12, color: COLORS.textMuted }} />
                  <Line type="monotone" dataKey="target2026" name="Target 2026" stroke={COLORS.blue} strokeWidth={2} strokeDasharray="8 4" dot={false} />
                  <Line type="monotone" dataKey="real2026" name="Real 2026" stroke={COLORS.accent} strokeWidth={3} dot={{ fill: COLORS.accent, r: 4 }} connectNulls={false} />
                  <Line type="monotone" dataKey="real2025" name="Real 2025" stroke={COLORS.gray} strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <SectionTitle>Comparativo Trimestral: 2026 vs 2025</SectionTitle>
            <div style={{ background: COLORS.card, borderRadius: 12, padding: 24, border: `1px solid ${COLORS.border}` }}>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={quarterData} barGap={8}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="q" tick={{ fill: COLORS.textMuted, fontSize: 13 }} />
                  <YAxis tick={{ fill: COLORS.textMuted, fontSize: 12 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="real" name="2026 (Real/Proj)" fill={COLORS.accent} radius={[6, 6, 0, 0]} />
                  <Bar dataKey="target" name="Target 2026" fill={COLORS.blue} radius={[6, 6, 0, 0]} opacity={0.35} />
                  <Bar dataKey="prev" name="2025 Real" fill={COLORS.gray} radius={[6, 6, 0, 0]} opacity={0.4} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <SectionTitle>Análisis de Brecha (Gap Analysis)</SectionTitle>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
              <div style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}` }}>
                <div style={{ color: COLORS.textMuted, fontSize: 12, marginBottom: 8, textTransform: "uppercase" }}>Gap Anual</div>
                <div style={{ fontSize: 36, fontWeight: 800, color: COLORS.red }}>${gapAnual.toFixed(0)}M</div>
                <div style={{ color: COLORS.textMuted, fontSize: 12, marginTop: 4 }}>
                  {((gapAnual / TARGET_ANUAL) * 100).toFixed(0)}% del target por cubrir
                </div>
                <ProgressBar value={totalReal} max={TARGET_ANUAL} color={COLORS.accent} height={10} />
              </div>
              <div style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}` }}>
                <div style={{ color: COLORS.textMuted, fontSize: 12, marginBottom: 8, textTransform: "uppercase" }}>Pipeline Q2 puede cubrir</div>
                <div style={{ fontSize: 36, fontWeight: 800, color: COLORS.green }}>${(totalPipeline * 9).toFixed(0)}M</div>
                <div style={{ color: COLORS.textMuted, fontSize: 12, marginTop: 4 }}>
                  si se convierten $101M/mes × 9 meses restantes
                </div>
                <div style={{ marginTop: 8, padding: "8px 12px", borderRadius: 8, background: "rgba(46,204,113,0.1)", fontSize: 12, color: COLORS.green }}>
                  Ponderado: ${(pipelinePonderado * 9).toFixed(0)}M (prob. ajustada)
                </div>
              </div>
              <div style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}` }}>
                <div style={{ color: COLORS.textMuted, fontSize: 12, marginBottom: 8, textTransform: "uppercase" }}>Escenario de cierre</div>
                <div style={{ fontSize: 14, lineHeight: 1.8, marginTop: 8 }}>
                  <div><span style={{ color: COLORS.green }}>●</span> <strong>Optimista:</strong> $3,150M (75%)</div>
                  <div><span style={{ color: COLORS.yellow }}>●</span> <strong>Base:</strong> $2,750M (65%)</div>
                  <div><span style={{ color: COLORS.red }}>●</span> <strong>Conservador:</strong> $2,530M (60%)</div>
                </div>
                <div style={{ marginTop: 12, padding: "8px 12px", borderRadius: 8, background: "rgba(231,76,60,0.1)", fontSize: 12, color: COLORS.red }}>
                  Necesitamos +$30M/mes en nuevas cuentas
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ══════ TAB: ACCOUNTS ══════ */}
        {activeTab === "accounts" && (
          <div>
            <SectionTitle>Distribución por Industria</SectionTitle>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}` }}>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={industryBreakdown} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis type="number" tick={{ fill: COLORS.textMuted, fontSize: 11 }} />
                    <YAxis type="category" dataKey="name" tick={{ fill: COLORS.textMuted, fontSize: 11 }} width={140} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="revenue" name="Revenue $M/mes" radius={[0, 6, 6, 0]}>
                      {industryBreakdown.map((entry, i) => (
                        <Cell key={i} fill={industryColors[entry.name] || COLORS.gray} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}` }}>
                <div style={{ color: COLORS.textMuted, fontSize: 12, fontWeight: 600, textTransform: "uppercase", marginBottom: 16 }}>Detalle por industria</div>
                {industryBreakdown.map((ind, i) => (
                  <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: i < industryBreakdown.length - 1 ? `1px solid ${COLORS.border}` : "none" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 10, height: 10, borderRadius: "50%", background: industryColors[ind.name] || COLORS.gray }} />
                      <span style={{ fontSize: 13 }}>{ind.name}</span>
                    </div>
                    <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
                      <span style={{ fontSize: 12, color: COLORS.textMuted }}>{ind.cuentas} cuentas</span>
                      <span style={{ fontSize: 14, fontWeight: 700, color: industryColors[ind.name] || COLORS.gray }}>${ind.revenue}M/mes</span>
                    </div>
                  </div>
                ))}
                <div style={{ marginTop: 16, padding: 12, background: "rgba(67,97,238,0.08)", borderRadius: 8, fontSize: 12, color: COLORS.blueLight }}>
                  <strong>Recomendación:</strong> Banca & Fintech y Public Affairs concentran el 65% del revenue. Diversificar en Consumo Masivo y Tecnología/IA donde hay pipeline activo.
                </div>
              </div>
            </div>

            {/* Account Table */}
            <SectionTitle>Listado de Cuentas Activas</SectionTitle>
            <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
              {industries.map(ind => (
                <button key={ind} onClick={() => setSelectedIndustry(ind)} style={{ padding: "6px 14px", borderRadius: 20, border: `1px solid ${selectedIndustry === ind ? COLORS.accent : COLORS.border}`, background: selectedIndustry === ind ? COLORS.accent : "transparent", color: selectedIndustry === ind ? "#fff" : COLORS.textMuted, fontSize: 12, cursor: "pointer", fontWeight: 500 }}>
                  {ind}
                </button>
              ))}
            </div>
            <div style={{ background: COLORS.card, borderRadius: 12, border: `1px solid ${COLORS.border}`, overflow: "hidden" }}>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ background: "rgba(255,255,255,0.03)" }}>
                      {["Cuenta", "Tipo", "Industria", "Servicio", "Ticket/mes", "AM", "Comercial"].map(h => (
                        <th key={h} style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 600, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 0.5, borderBottom: `1px solid ${COLORS.border}` }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCuentas.map((c, i) => (
                      <tr key={i} style={{ borderBottom: `1px solid ${COLORS.border}`, background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.01)" }}>
                        <td style={{ padding: "10px 16px", fontSize: 13, fontWeight: 600 }}>{c.nombre}</td>
                        <td style={{ padding: "10px 16px" }}>
                          <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 12, background: c.tipo === "Recurrente" ? "rgba(46,204,113,0.12)" : "rgba(243,156,18,0.12)", color: c.tipo === "Recurrente" ? COLORS.green : COLORS.yellow }}>{c.tipo}</span>
                        </td>
                        <td style={{ padding: "10px 16px" }}>
                          <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 12, background: `${industryColors[c.industria] || COLORS.gray}15`, color: industryColors[c.industria] || COLORS.gray }}>{c.industria}</span>
                        </td>
                        <td style={{ padding: "10px 16px", fontSize: 12, color: COLORS.textMuted }}>{c.servicio}</td>
                        <td style={{ padding: "10px 16px", fontSize: 13, fontWeight: 700, color: COLORS.accent }}>${c.ticketMes}M</td>
                        <td style={{ padding: "10px 16px", fontSize: 12 }}>{c.am}</td>
                        <td style={{ padding: "10px 16px", fontSize: 12 }}>{c.comercial}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ══════ TAB: PIPELINE ══════ */}
        {activeTab === "pipeline" && (
          <div>
            <SectionTitle>Funnel de Ventas</SectionTitle>
            <div style={{ background: COLORS.card, borderRadius: 12, padding: 24, border: `1px solid ${COLORS.border}` }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {funnelStages.map((s, i) => {
                  const maxW = 100;
                  const w = (s.value / funnelStages[funnelStages.length - 1].value) * maxW;
                  const funnelColors = [COLORS.gray, COLORS.blue, COLORS.teal, COLORS.yellow, COLORS.orange, COLORS.green];
                  return (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 16 }}>
                      <div style={{ width: 80, textAlign: "right", fontSize: 12, fontWeight: 600, color: COLORS.textMuted }}>{s.stage}</div>
                      <div style={{ flex: 1, position: "relative" }}>
                        <div style={{ width: `${Math.max(w, 15)}%`, height: 40, background: `linear-gradient(90deg, ${funnelColors[i]}CC, ${funnelColors[i]}66)`, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px", transition: "width 0.5s" }}>
                          <span style={{ fontSize: 13, fontWeight: 700 }}>{s.count} ops</span>
                          <span style={{ fontSize: 13, fontWeight: 700 }}>${s.value}M</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div style={{ marginTop: 16, display: "flex", gap: 16, justifyContent: "center" }}>
                <span style={{ fontSize: 12, color: COLORS.textMuted }}>Tasa Lead→Won: <strong style={{ color: COLORS.green }}>28%</strong></span>
                <span style={{ fontSize: 12, color: COLORS.textMuted }}>Tiempo promedio cierre: <strong style={{ color: COLORS.yellow }}>45 días</strong></span>
                <span style={{ fontSize: 12, color: COLORS.textMuted }}>Win rate Q1: <strong style={{ color: COLORS.green }}>67%</strong></span>
              </div>
            </div>

            <SectionTitle>Pipeline Q2 2026 — Oportunidades por cerrar</SectionTitle>
            <div style={{ display: "grid", gap: 12 }}>
              {pipelineQ2.map((p, i) => (
                <div key={i} style={{ background: COLORS.card, borderRadius: 12, padding: "16px 20px", border: `1px solid ${COLORS.border}`, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 8, height: 40, borderRadius: 4, background: industryColors[p.industria] || COLORS.gray }} />
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 700 }}>{p.nombre}</div>
                      <div style={{ fontSize: 11, color: COLORS.textMuted }}>{p.industria} · Inicio: {p.inicio}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.accent }}>${p.ticketMes}M</div>
                      <div style={{ fontSize: 10, color: COLORS.textMuted }}>/mes</div>
                    </div>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: 18, fontWeight: 800, color: p.probabilidad >= 70 ? COLORS.green : p.probabilidad >= 55 ? COLORS.yellow : COLORS.orange }}>{p.probabilidad}%</div>
                      <div style={{ fontSize: 10, color: COLORS.textMuted }}>prob.</div>
                    </div>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.blueLight }}>${(p.ticketMes * p.probabilidad / 100).toFixed(0)}M</div>
                      <div style={{ fontSize: 10, color: COLORS.textMuted }}>ponderado</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}`, marginTop: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-around", textAlign: "center" }}>
                <div>
                  <div style={{ fontSize: 28, fontWeight: 800, color: COLORS.accent }}>${totalPipeline}M</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>Pipeline total/mes</div>
                </div>
                <div style={{ width: 1, background: COLORS.border }} />
                <div>
                  <div style={{ fontSize: 28, fontWeight: 800, color: COLORS.green }}>${pipelinePonderado.toFixed(0)}M</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>Ponderado/mes</div>
                </div>
                <div style={{ width: 1, background: COLORS.border }} />
                <div>
                  <div style={{ fontSize: 28, fontWeight: 800, color: COLORS.blue }}>${(totalPipeline * 12).toFixed(0)}M</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>Anualizado</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ══════ TAB: TEAM ══════ */}
        {activeTab === "team" && (
          <div>
            <SectionTitle>Performance del Equipo Comercial</SectionTitle>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16 }}>
              {comercialBreakdown.map((c, i) => {
                const colores = [COLORS.accent, COLORS.blue, COLORS.green, COLORS.purple, COLORS.orange];
                const rolDesc = c.name === "Sergio" ? "CEO · Sponsor Ejecutivo del Modelo" : c.name === "Diego" ? "Gerente Comercial (Cerrador)" : c.name === "Sol" ? "COO · Cliente conocido / Producto conocido" : "Comercial";
                const cuotaMensual = c.name === "Diego" ? 50 : null;
                return (
                  <div key={i} style={{ background: COLORS.card, borderRadius: 12, padding: 20, border: `1px solid ${COLORS.border}`, position: "relative", overflow: "hidden" }}>
                    <div style={{ position: "absolute", top: 0, left: 0, width: "100%", height: 3, background: colores[i % colores.length] }} />
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
                      <div>
                        <div style={{ fontSize: 18, fontWeight: 800 }}>{c.name}</div>
                        <div style={{ fontSize: 11, color: COLORS.textMuted, marginTop: 2 }}>{rolDesc}</div>
                      </div>
                      <div style={{ width: 42, height: 42, borderRadius: "50%", background: `${colores[i % colores.length]}22`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 800, color: colores[i % colores.length] }}>
                        {c.name[0]}
                      </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                      <div>
                        <div style={{ fontSize: 24, fontWeight: 800, color: colores[i % colores.length] }}>{c.cuentas}</div>
                        <div style={{ fontSize: 11, color: COLORS.textMuted }}>Cuentas</div>
                      </div>
                      <div>
                        <div style={{ fontSize: 24, fontWeight: 800, color: colores[i % colores.length] }}>${c.revenue}M</div>
                        <div style={{ fontSize: 11, color: COLORS.textMuted }}>Revenue/mes</div>
                      </div>
                    </div>
                    {cuotaMensual && (
                      <div style={{ marginTop: 8 }}>
                        <div style={{ fontSize: 11, color: COLORS.textMuted, marginBottom: 4 }}>Cuota mensual: ${cuotaMensual}M</div>
                        <ProgressBar value={c.revenue} max={cuotaMensual} color={c.revenue >= cuotaMensual ? COLORS.green : COLORS.yellow} height={6} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <SectionTitle>Modelo Comercial MVP 2026</SectionTitle>
            <div style={{ background: COLORS.card, borderRadius: 12, padding: 24, border: `1px solid ${COLORS.border}` }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 20 }}>
                <div style={{ padding: 16, borderRadius: 8, background: "rgba(67,97,238,0.08)" }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.blue, marginBottom: 8 }}>Pool Comercial</div>
                  <div style={{ fontSize: 28, fontWeight: 800 }}>20%</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>del pricing va a estructura comercial</div>
                </div>
                <div style={{ padding: 16, borderRadius: 8, background: "rgba(46,204,113,0.08)" }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.green, marginBottom: 8 }}>Business Owner</div>
                  <div style={{ fontSize: 28, fontWeight: 800 }}>2.5%</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>del revenue del vertical</div>
                </div>
                <div style={{ padding: 16, borderRadius: 8, background: "rgba(233,69,96,0.08)" }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.accent, marginBottom: 8 }}>Referral</div>
                  <div style={{ fontSize: 28, fontWeight: 800 }}>7.5%</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>sin cap, ilimitado</div>
                </div>
                <div style={{ padding: 16, borderRadius: 8, background: "rgba(155,89,182,0.08)" }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.purple, marginBottom: 8 }}>Apertura + Cierre</div>
                  <div style={{ fontSize: 28, fontWeight: 800 }}>15%</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>si la misma persona abre y cierra</div>
                </div>
              </div>
              <div style={{ marginTop: 20, padding: 16, borderRadius: 8, background: "rgba(255,255,255,0.03)", border: `1px solid ${COLORS.border}` }}>
                <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>Revenue Split</div>
                <div style={{ display: "flex", gap: 4, height: 24, borderRadius: 6, overflow: "hidden" }}>
                  <div style={{ width: "60%", background: COLORS.blue, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700 }}>Creatividad 60%</div>
                  <div style={{ width: "40%", background: COLORS.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700 }}>Comercial 40%</div>
                </div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 8 }}>
                  Del target de $4,200M: Creatividad debe generar $2,520M · Comercial debe generar $1,680M
                </div>
              </div>
            </div>

            <SectionTitle>Matriz de Crecimiento (Ansoff)</SectionTitle>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2, background: COLORS.border, borderRadius: 12, overflow: "hidden" }}>
              <div style={{ background: COLORS.card, padding: 20 }}>
                <div style={{ fontSize: 11, color: COLORS.textMuted, textTransform: "uppercase", marginBottom: 8 }}>Cliente conocido × Producto conocido</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: COLORS.green }}>Sol Rios Brinatti (COO)</div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 4 }}>Retención, upselling, cross-selling en base instalada</div>
              </div>
              <div style={{ background: COLORS.card, padding: 20 }}>
                <div style={{ fontSize: 11, color: COLORS.textMuted, textTransform: "uppercase", marginBottom: 8 }}>Cliente nuevo × Producto conocido</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: COLORS.blue }}>Diego Kupferberg (GC)</div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 4 }}>Cámaras empresariales, acompañamientos privados</div>
              </div>
              <div style={{ background: COLORS.card, padding: 20 }}>
                <div style={{ fontSize: 11, color: COLORS.textMuted, textTransform: "uppercase", marginBottom: 8 }}>Cliente conocido × Producto nuevo</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: COLORS.yellow }}>Matías Fermín (Banca & Fintech)</div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 4 }}>Generador de deals en el vertical financiero</div>
              </div>
              <div style={{ background: COLORS.card, padding: 20 }}>
                <div style={{ fontSize: 11, color: COLORS.textMuted, textTransform: "uppercase", marginBottom: 8 }}>Cliente nuevo × Producto nuevo</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: COLORS.accent }}>Sergio Doval (CEO)</div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 4 }}>Foco estratégico, nuevos mercados y productos</div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div style={{ textAlign: "center", padding: "32px 0 16px", color: COLORS.textMuted, fontSize: 11 }}>
          Tablero del Director Comercial · Grupo Taquion · Datos de Notion CRM · {new Date().toLocaleDateString("es-AR")}
        </div>
      </div>
    </div>
  );
}
